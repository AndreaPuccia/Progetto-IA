import pandas as pd
import sklearn.utils as sku
from Learning import DT_Learn
from Testing import TestData
from Pruning import Pruning
from Tree import tree

print("Dataset Plant")
# preparo i dati li leggo dal file e li divido in training_set & validation_set & test_set
data = pd.read_csv('plant-classification.csv', names=['A', 'B', 'C', 'D', 'E', 'F', 'Y'])
training_set = data.iloc[0:1400].reset_index(drop=True)
validation_set = data.iloc[1400:2000].reset_index(drop=True)
test_set = data.iloc[2000:].reset_index(drop=True)
# preparo i parametri da passare a DT_Learn
attr = ['A', 'B', 'C', 'D', 'E', 'F']
pData = []
# creo l'albero di decisione
# albero non potato
tree0 = tree(DT_Learn(training_set, attr, pData))
print("Albero Non Potato")
print("Nodi: ", end="")
tree0.countNodes()
err = TestData(tree0, test_set)
print("Errori: ", err)
print("Errore Percentuale: ", (round((err/test_set.__len__())*100,4)), "%")
# albero potato
pruningTree = Pruning(tree0, validation_set)
print("Albero Potato")
print("Nodi: ", end="")
pruningTree.countNodes()
err = TestData(pruningTree, test_set)
print("Errrori: ", err)
print("Errore Percentuale: ", (round((err/test_set.__len__())*100,4)), "%")

# ****************************************************************************************

print("")
print("Dataset Cars")
# preparo i dati li leggo dal file e li divido in training_set & validation_set & test_set
data1 = pd.read_csv('cars.csv', names=['A', 'B', 'C', 'D', 'E', 'F', 'Y'])
# 276 432
data1 = sku.shuffle(data1, random_state=276).reset_index(drop=True)
training_set1 = data1.iloc[0:1000].reset_index(drop=True)
validation_set1 = data1.iloc[1000:1350].reset_index(drop=True)
test_set1 = data1.iloc[1350:].reset_index(drop=True)
# preparo i parametri da passare a DT_Learn
attr1 = ['A', 'B', 'C', 'D', 'E', 'F']
pData1 = []
# creo l'albero di decisione
# albero non potato
tree1 = tree(DT_Learn(training_set1, attr1, pData1))
err1 = TestData(tree1, test_set1)
print("ALbero Non Potato")
print("Nodi: ", end="")
tree1.countNodes()
print("Errori: ", err1)
print("Errore Percentuale: ", (round((err1/test_set1.__len__())*100,4)), "%")
# albero potato
pruningTree1 = Pruning(tree1, validation_set1)
err1 = TestData(pruningTree1, test_set1)
print("Albero Potato")
print("Nodi: ", end="")
pruningTree1.countNodes()
print("Errrori: ", err1)
print("Errore Percentuale: ", (round((err1/test_set1.__len__())*100,4)), "%")

# ****************************************************************************************

print("")
print("Dataset Nursery")
# preparo i dati li leggo dal file e li divido in training_set & validation_set & test_set
data2 = pd.read_csv("nursery.csv", names=['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'Y'])
data2 = sku.shuffle(data2, random_state=676).reset_index(drop=True)
training_set2 = data2.iloc[0:6400].reset_index(drop=True)
validation_set2 = data2.iloc[6400:9100].reset_index(drop=True)
test_set2 = data2.iloc[9100:].reset_index(drop=True)
# preparo i parametri da passare a DT_Learn
attr2 = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']
pData2 = []
# creo l'albero di decisione
# albero non potato
tree2 = tree(DT_Learn(training_set2, attr2, pData2))
print("Albero Non Potato")
print("Nodi: ", end="")
tree2.countNodes()
err2 = TestData(tree2, test_set2)
print("Errori: ", err2)
print("Errore Percentuale: ", (round((err2/test_set2.__len__())*100,4)), "%")
# albero potato
pruningTree2 = Pruning(tree2, validation_set2)
print("Albero Potato")
print("Nodi: ", end="")
pruningTree2.countNodes()
err2 = TestData(pruningTree2, test_set2)
print("Errrori: ", err2)
print("Errore Percentuale: ", (round((err2/test_set2.__len__())*100,4)), "%")


