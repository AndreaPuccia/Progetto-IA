Come procedere:
(In allegato sono stati riportati anche i dataset in quanto essi sono stati trasformati in formato csv per utilizzarli) 
1 Dopo aver scaricato i file accertarsi che dataset e file .py siano nella stessa cartella
2 Accertarsi che le librerie sotto riportate siano correttamente installate
3 Eseguire il file test.py

Sono state utilizzate 3 librerie:
	-pandas
	-numpy
	-sklearn.utils

Elenco dei file presenti:
	File Python
		-Learning.py
		-Node.py
		-Pruning.py
		-test.py
		-Testing.py
		-Tree.py
	Dataset
		-cars.csv
		-nursery.csv
		-plant-classification.csv
		
		